Screenshots:
- Capture 2?8 screenshots from the app on device (portrait).
- Recommended size: 1080x1920 PNG.

Privacy Policy:
- Host politica.html publicly and paste the URL in Play Console.
